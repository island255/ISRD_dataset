var searchData=
[
  ['level',['level',['../structlzg__encoder__config__t.html#a7cead514ac7e24664a6c5372d175d5b9',1,'lzg_encoder_config_t']]]
];
