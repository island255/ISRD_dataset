var searchData=
[
  ['fast',['fast',['../structlzg__encoder__config__t.html#a810cabd7c7e51f508abb7cc9dacd81ab',1,'lzg_encoder_config_t']]]
];
