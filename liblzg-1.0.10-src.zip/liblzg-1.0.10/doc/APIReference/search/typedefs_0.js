var searchData=
[
  ['lzg_5fbool_5ft',['lzg_bool_t',['../lzg_8h.html#a1fd0b2ead5b62ea972ea8262e39c19a1',1,'lzg.h']]],
  ['lzg_5fint32_5ft',['lzg_int32_t',['../lzg_8h.html#a852dc5a49858595d0bd1085da9596e09',1,'lzg.h']]],
  ['lzg_5fuint32_5ft',['lzg_uint32_t',['../lzg_8h.html#acc65d427597199a98f3868c621c46156',1,'lzg.h']]],
  ['lzgprogressfun',['LZGPROGRESSFUN',['../lzg_8h.html#ad10aa2c26a91a9dcce9e43ff03d63d8e',1,'lzg.h']]]
];
