var searchData=
[
  ['lzg_5fdecode',['LZG_Decode',['../lzg_8h.html#afeb61540cbd5c16c1d9cc4be3e104961',1,'lzg.h']]],
  ['lzg_5fdecodedsize',['LZG_DecodedSize',['../lzg_8h.html#a4928d4e43fd0cfb227504f6ad5cd0167',1,'lzg.h']]],
  ['lzg_5fencode',['LZG_Encode',['../lzg_8h.html#a1ec248f37917054f3b2449fd507c08de',1,'lzg.h']]],
  ['lzg_5fencodefull',['LZG_EncodeFull',['../lzg_8h.html#a431c7c0071a27e6a89f10bd42b1ad3e1',1,'lzg.h']]],
  ['lzg_5finitencoderconfig',['LZG_InitEncoderConfig',['../lzg_8h.html#a84499d3fef59ca0e1b78054ae8b70357',1,'lzg.h']]],
  ['lzg_5fmaxencodedsize',['LZG_MaxEncodedSize',['../lzg_8h.html#a369411488db987a1bc8d75a5b4b00113',1,'lzg.h']]],
  ['lzg_5fversion',['LZG_Version',['../lzg_8h.html#a881459e5eac5d5f9bc929b3900077050',1,'lzg.h']]],
  ['lzg_5fversionstring',['LZG_VersionString',['../lzg_8h.html#a7b8d7ad3793e9587aad97b232064181b',1,'lzg.h']]],
  ['lzg_5fworkmemsize',['LZG_WorkMemSize',['../lzg_8h.html#a7f3136fe8b34cac499a15499ce35c165',1,'lzg.h']]]
];
