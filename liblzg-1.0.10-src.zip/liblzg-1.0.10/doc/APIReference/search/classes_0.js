var searchData=
[
  ['lzg_5fencoder_5fconfig_5ft',['lzg_encoder_config_t',['../structlzg__encoder__config__t.html',1,'']]]
];
