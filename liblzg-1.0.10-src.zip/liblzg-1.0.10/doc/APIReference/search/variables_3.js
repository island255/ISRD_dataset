var searchData=
[
  ['userdata',['userdata',['../structlzg__encoder__config__t.html#a5b2f59ae49ef739255c6b0abe1821bdc',1,'lzg_encoder_config_t']]]
];
