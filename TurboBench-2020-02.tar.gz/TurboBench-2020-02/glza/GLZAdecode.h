#if defined (__cplusplus)
extern "C" {
#endif
  uint8_t * GLZAdecode(size_t insize, uint8_t * inbuf, size_t * outsize_ptr, uint8_t * outbuf,
      FILE * fd_out, struct param_data * params);
#if defined (__cplusplus)
}
#endif
