uint8_t GLZAcompress(size_t insize, size_t * outsize_ptr, uint8_t ** iobuf, struct param_data * params);
