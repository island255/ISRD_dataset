FastARI
=======

A Fast Bitwise Arithmetic Compressor
