#ifdef __cplusplus
extern "C" {
#endif
int vecrcenc(unsigned char *ip, int ilen, unsigned char *op);
int vecrcdec(unsigned char *ip, int olen, unsigned char *op);
#ifdef __cplusplus
}
#endif
