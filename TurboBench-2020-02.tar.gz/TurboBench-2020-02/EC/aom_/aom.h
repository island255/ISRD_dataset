#ifdef __cplusplus
extern "C" {
#endif
int aomenc( unsigned char *in, unsigned inlen, unsigned char *out, unsigned outsize);
int aomdec( unsigned char *in, unsigned inlen, unsigned char *out, unsigned outlen );
#ifdef __cplusplus
}
#endif
