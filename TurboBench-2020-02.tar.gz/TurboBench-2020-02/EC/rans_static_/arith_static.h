#ifdef __cplusplus
extern "C" {
#endif
unsigned char *arith_compress_O0(  unsigned char *in, unsigned int in_size, unsigned int *out_size, unsigned char *out_buf);
unsigned char *arith_uncompress_O0(unsigned char *in, unsigned int in_size, unsigned int *out_size, unsigned char *out_buf);
unsigned char *arith_compress_O1(  unsigned char *in, unsigned int in_size, unsigned int *out_size, unsigned char *out_buf);
unsigned char *arith_uncompress_O1(unsigned char *in, unsigned int in_size, unsigned int *out_size, unsigned char *out_buf);
#ifdef __cplusplus
}
#endif



