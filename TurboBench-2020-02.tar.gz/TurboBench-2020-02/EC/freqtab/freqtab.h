#ifdef __cplusplus
extern "C" {
#endif
int freqtabenc(unsigned char *in, int inlen, unsigned char *out, int outsize);
int freqtabdec(unsigned char *in, int inlen, unsigned char *out, int outlen);
#ifdef __cplusplus
}
#endif

