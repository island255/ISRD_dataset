
uint C_get_object_size( void );
void C_init( void* p );
uint C_process( void* p, uint f_DEC );
uint C_getoutsize( void* p );
void C_addinp( void* p, byte* inp,uint inplen );
void C_addout( void* p, byte* out,uint outlen );
