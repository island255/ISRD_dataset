#ifdef __cplusplus
extern "C" {
#endif
int daalaenc( unsigned char *in, unsigned inlen, unsigned char *out, unsigned outsize);
int daaladec( unsigned char *in, unsigned inlen, unsigned char *out, unsigned outlen );
#ifdef __cplusplus
}
#endif

