extern "C" uint8_t GLZAcomp(size_t insize, uint8_t * inbuf, size_t * outsize_ptr, uint8_t * outbuf, FILE * fd, struct param_data * params);
