extern "C" uint8_t * GLZAdecode(size_t insize, uint8_t * inbuf, size_t * outsize_ptr, uint8_t * outbuf, FILE * fd_out);
