struct param_data {
  uint8_t user_set_profit_ratio_power, user_set_production_cost, user_set_RAM_size;
  double production_cost, profit_ratio_power, RAM_usage;
} params;
