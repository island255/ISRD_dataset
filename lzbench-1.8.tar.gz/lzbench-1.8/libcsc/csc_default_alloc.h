#ifndef _CSC_DEFAULT_ALLOC_H_
#define _CSC_DEFAULT_ALLOC_H_
#include <csc_common.h>

extern ISzAlloc *default_alloc;

#endif

