# SndFile2K

Fork of [libsndfile](http://www.mega-nerd.com/libsndfile/) library, a C library for reading and writing files containing sampled audio data.

# Introduction

The short way to start is [Basic sound file manipulation](@ref file-base) section describing how to open/close sound file, then continue reading [Read/Write frames](@ref read-write-frames) and [Read/Write items](@ref read-write-items) where you can find information about how to read/write sound data.

